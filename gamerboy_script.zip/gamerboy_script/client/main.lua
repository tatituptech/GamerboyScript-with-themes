local QBCore = exports['qb-core']:GetCoreObject()
local placedEntity = nil
local placedNetId = nil
local isOpen = false

-- Helper: load model
local function loadModel(hash)
    local model = (type(hash) == "string" and GetHashKey(hash) or hash)
    if not IsModelInCdimage(model) then return false end
    RequestModel(model)
    local timeout = 50
    while not HasModelLoaded(model) and timeout > 0 do
        Wait(10)
        timeout = timeout - 1
    end
    return HasModelLoaded(model)
end

-- Place a prop in front of player
local function placeProp()
    local ped = PlayerPedId()
    local pos = GetEntityCoords(ped)
    local forward = GetEntityForwardVector(ped)
    local spawnPos = pos + forward * 1.0
    spawnPos = vector3(spawnPos.x, spawnPos.y, spawnPos.z)

    if placedEntity and DoesEntityExist(placedEntity) then
        DeleteEntity(placedEntity)
        placedEntity = nil
        placedNetId = nil
    end

    local ok = loadModel(Config.PropModel)
    if not ok then
        QBCore.Functions.Notify("Failed to load prop model. Change Config.PropModel to a valid model.", "error")
        return
    end

    local propHash = GetHashKey(Config.PropModel)
    local obj = CreateObject(propHash, spawnPos.x, spawnPos.y, spawnPos.z, true, false, true)
    if DoesEntityExist(obj) then
        PlaceObjectOnGroundProperly(obj)
        FreezeEntityPosition(obj, true)
        SetEntityAsMissionEntity(obj, true, true)

        if Config.FacePlayerOnPlace then
            local heading = GetEntityHeading(PlayerPedId())
            SetEntityHeading(obj, heading + 180.0)
        end

        placedEntity = obj
        placedNetId = ObjToNet(obj)

        -- Register target if qb-target is installed
        if exports['qb-target'] then
            exports['qb-target']:AddTargetEntity(obj, {
                options = {
                    {
                        type = "client",
                        event = "qb-gameboy:client:open",
                        icon = "fa-solid fa-gamepad",
                        label = "Play Gameboy"
                    }
                },
                distance = 2.5
            })
        end

        QBCore.Functions.Notify("Gameboy placed. Interact with it to play.", "success")
    else
        QBCore.Functions.Notify("Failed to create prop.", "error")
    end
end

-- Remove placed prop (used on resource stop)
local function cleanupProp()
    if placedEntity and DoesEntityExist(placedEntity) then
        if exports['qb-target'] then
            pcall(function()
                exports['qb-target']:RemoveZone(placedEntity)
                -- RemoveTargetEntity is not always available; best effort only
            end)
        end

        SetEntityAsMissionEntity(placedEntity, false, true)
        DeleteEntity(placedEntity)
        placedEntity = nil
        placedNetId = nil
    end
end

-- Open the NUI
local function openNui()
    if isOpen then return end
    isOpen = true
    SetNuiFocus(true, Config.NuiOptions.allowCursor)
    SendNUIMessage({action = "open"})
    -- play a little animation (sit/stand or hold)
    local ped = PlayerPedId()
    TaskStartScenarioInPlace(ped, "WORLD_HUMAN_SEAT_WALL_TABLET", 0, true)
end

-- Close the NUI
local function closeNui()
    if not isOpen then return end
    isOpen = false
    SetNuiFocus(false, false)
    SendNUIMessage({action = "close"})
    ClearPedTasks(PlayerPedId())
end

-- Event exposed to open NUI
RegisterNetEvent('qb-gameboy:client:open', function(data)
    openNui()
end)

-- Place the prop (called from server CreateUseableItem)
RegisterNetEvent('qb-gameboy:client:place', function()
    placeProp()
end)

-- NUI callbacks
RegisterNUICallback('close', function(_, cb)
    closeNui()
    cb('ok')
end)

RegisterNUICallback('saveState', function(state, cb)
    -- Optionally persist to server/player metadata. For now we save client-side in the NUI localStorage.
    -- If you want server persistence, emit server event here with state.data as base64 or JSON.
    cb('ok')
end)

-- If qb-target is not available, fallback to showing prompt and keybind
Citizen.CreateThread(function()
    while true do
        Wait(1000)
        if not exports['qb-target'] then
            -- nothing to do each second unless there is a prop
            if placedEntity and DoesEntityExist(placedEntity) then
                local ped = PlayerPedId()
                local ppos = GetEntityCoords(ped)
                local epos = GetEntityCoords(placedEntity)
                local dist = #(ppos - epos)
                if dist <= Config.InteractDistance then
                    -- draw help text
                    local str = "[E] Play Gameboy"
                    SetTextFont(0)
                    SetTextProportional(1)
                    SetTextScale(0.35, 0.35)
                    SetTextColour(255, 255, 255, 215)
                    SetTextEntry("STRING")
                    AddTextComponentString(str)
                    DrawText(0.5, 0.9) -- center bottom
                    if IsControlJustReleased(0, 38) then -- E
                        openNui()
                    end
                end
            end
        else
            Wait(2000) -- if qb-target exists we don't need to check every second
        end
    end
end)

-- Cleanup on resource stop
AddEventHandler('onResourceStop', function(resourceName)
    if resourceName == GetCurrentResourceName() then
        cleanupProp()
    end
end)

-- Optional command to remove placed prop
RegisterCommand("removegameboy", function()
    cleanupProp()
    QBCore.Functions.Notify("Gameboy removed.", "success")
end)