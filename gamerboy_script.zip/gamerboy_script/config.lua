-- Configuration for qb-gameboy
Config = {}

-- Default prop model. Change to the model you want (or set up a usable item only)
-- Note: Some servers include handheld props. If a model doesn't spawn, change it or set the item/command to only open UI.
Config.PropModel = "prop_cs_hand_radio" -- change to your preferred prop

-- Usable item name. Server will register an item with this name as usable.
-- Create this item in your items.lua / qb-core item definitions (name = "gameboy", label = "Gameboy", etc.)
Config.UsableItem = "gameboy"

-- Distance at which players can interact with the spawned prop (when qb-target is not available)
Config.InteractDistance = 2.0

-- Whether to auto-rotate the prop to face the player when placed
Config.FacePlayerOnPlace = true

-- NUI focus options
Config.NuiOptions = {
  allowCursor = true
}