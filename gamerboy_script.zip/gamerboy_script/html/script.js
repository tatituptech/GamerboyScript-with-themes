// Minimal NUI script for the Gameboy UI.
// This file provides a UI shell that will try to load html/emulator/emulator.js if present.
// The emulator must expose a minimal API that this file expects OR you must adapt this file
// to match your chosen emulator's API.
//
// Expected minimal emulator API (example):
//   window.Emulator = {
//     init: function(canvas) { /* prepare */ },
//     loadROM: async function(arrayBuffer) { /* start ROM */ },
//     saveState: function() { return /* state blob (ArrayBuffer or base64) */ },
//     loadState: function(state) { /* restore */ },
//     stop: function() { /* stop emulation */ }
//   };
//
// If your emulator uses a different API, adapt these calls accordingly.

const app = document.getElementById('app')
const btnLoadRom = document.getElementById('btn-load-rom')
const inputRom = document.getElementById('input-rom')
const btnClose = document.getElementById('btn-close')
const btnSaveState = document.getElementById('btn-save-state')
const btnLoadState = document.getElementById('btn-load-state')
const romsUl = document.getElementById('roms-ul')
const emulatorWarning = document.getElementById('emulator-warning')
const canvas = document.getElementById('gb-screen')

let emulatorAvailable = false
let currentState = null

// Listen for messages from the game (client.lua)
window.addEventListener('message', (event) => {
  const d = event.data
  if (d.action === 'open') {
    openUI()
  } else if (d.action === 'close') {
    closeUI()
  }
})

function openUI() {
  app.classList.remove('hidden')
}

function closeUI() {
  app.classList.add('hidden')
  // stop emulator if present
  if (window.Emulator && typeof window.Emulator.stop === 'function') {
    try { window.Emulator.stop() } catch(e) { console.warn(e) }
  }
  // notify client to remove focus
  fetch(`https://${GetParentResourceName()}/close`, { method: 'POST', body: JSON.stringify({}) })
}

// Try to load emulator script if present
(function tryLoadEmulator(){
  const url = 'emulator/emulator.js'
  fetch(url, { method: 'HEAD' }).then(res => {
    if (res.ok) {
      const s = document.createElement('script')
      s.src = url
      s.onload = () => {
        emulatorAvailable = true
        emulatorWarning.classList.add('hidden')
        if (window.Emulator && typeof window.Emulator.init === 'function') {
          try {
            window.Emulator.init(canvas)
          } catch (e) {
            console.error('Emulator init error', e)
          }
        }
      }
      s.onerror = () => { emulatorAvailable = false; emulatorWarning.classList.remove('hidden') }
      document.body.appendChild(s)
    } else {
      emulatorAvailable = false
      emulatorWarning.classList.remove('hidden')
    }
  }).catch(() => {
    emulatorAvailable = false
    emulatorWarning.classList.remove('hidden')
  })
})()

// List built-in ROMs in html/roms directory if available
(function listRomFolder(){
  const dir = 'roms/'
  fetch(dir).then(res => {
    // Some servers allow directory listing, some don't. We try to fetch index or the file directly.
    // Fall back: display instruction to drop ROMs in html/roms/.
    // If your server doesn't list the folder, you can modify this to hardcode ROM filenames.
    if (!res.ok) throw 'no listing'
    return res.text()
  }).then(text => {
    // crude parsing for links (works if directory index is enabled)
    const parser = new DOMParser()
    const doc = parser.parseFromString(text, 'text/html')
    const links = Array.from(doc.querySelectorAll('a')).map(a => a.getAttribute('href')).filter(h => h && (h.endsWith('.gb') || h.endsWith('.gbc')))
    if (links.length === 0) {
      romsUl.innerHTML = '<li>No ROMs found. Drop .gb files into html/roms/</li>'
    } else {
      romsUl.innerHTML = ''
      links.forEach(l => {
        const li = document.createElement('li')
        li.textContent = l
        li.addEventListener('click', () => {
          fetch(`roms/${l}`).then(r => r.arrayBuffer()).then(buf => {
            if (window.Emulator && typeof window.Emulator.loadROM === 'function') {
              window.Emulator.loadROM(buf)
            } else {
              alert('Emulator library not available. Place emulator at html/emulator/emulator.js')
            }
          }).catch(e => console.error(e))
        })
        romsUl.appendChild(li)
      })
    }
  }).catch(() => {
    romsUl.innerHTML = '<li>No ROMs found. Drop .gb files into html/roms/</li>'
  })
})()

// file input for local ROMs
btnLoadRom.addEventListener('click', () => inputRom.click())
inputRom.addEventListener('change', (ev) => {
  const f = ev.target.files[0]
  if (!f) return
  const reader = new FileReader()
  reader.onload = function() {
    const buf = reader.result
    if (window.Emulator && typeof window.Emulator.loadROM === 'function') {
      window.Emulator.loadROM(buf)
    } else {
      alert('Emulator library not available. Place emulator at html/emulator/emulator.js')
    }
  }
  reader.readAsArrayBuffer(f)
})

btnClose.addEventListener('click', () => {
  closeUI()
})

btnSaveState.addEventListener('click', () => {
  if (window.Emulator && typeof window.Emulator.saveState === 'function') {
    try {
      const state = window.Emulator.saveState()
      // store in localStorage as base64 if it's an ArrayBuffer
      if (state instanceof ArrayBuffer) {
        const b64 = arrayBufferToBase64(state)
        localStorage.setItem('qb_gameboy_state', b64)
        alert('State saved locally.')
      } else {
        localStorage.setItem('qb_gameboy_state', JSON.stringify(state))
        alert('State saved locally.')
      }
    } catch (e) {
      console.error(e)
      alert('Failed to save state: ' + e)
    }
  } else {
    alert('Emulator does not support saveState.')
  }
})

btnLoadState.addEventListener('click', () => {
  const s = localStorage.getItem('qb_gameboy_state')
  if (!s) { alert('No saved state found.'); return }
  if (window.Emulator && typeof window.Emulator.loadState === 'function') {
    try {
      // attempt to decode base64
      if (isBase64(s)) {
        const buf = base64ToArrayBuffer(s)
        window.Emulator.loadState(buf)
      } else {
        window.Emulator.loadState(JSON.parse(s))
      }
      alert('State loaded.')
    } catch (e) {
      console.error(e)
      alert('Failed to load state: ' + e)
    }
  } else {
    alert('Emulator does not support loadState.')
  }
})

// Utility helpers
function arrayBufferToBase64(buffer) {
  let binary = ''
  const bytes = new Uint8Array(buffer)
  const len = bytes.byteLength
  for (let i = 0; i < len; i++) {
    binary += String.fromCharCode(bytes[i])
  }
  return btoa(binary)
}
function base64ToArrayBuffer(base64) {
  const binary_string = atob(base64)
  const len = binary_string.length
  const bytes = new Uint8Array(len)
  for (let i = 0; i < len; i++) {
    bytes[i] = binary_string.charCodeAt(i)
  }
  return bytes.buffer
}
function isBase64(str) {
  try {
    return btoa(atob(str)) === str
  } catch (err) {
    return false
  }
}

// NUI callbacks to/from client (FiveM)
function fetchNui(path, body) {
  return fetch(`https://${GetParentResourceName()}/${path}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json; charset=utf-8' },
    body: JSON.stringify(body || {})
  }).then(r => r.json())
}

// Expose a handler for close sent from client (optional)
window.addEventListener('message', (e) => {
  // currently handled above
})

/* Example: If your emulator does not provide the simple API above, you will need to adapt
   loadROM, saveState, loadState calls to your emulator's provided functions. */