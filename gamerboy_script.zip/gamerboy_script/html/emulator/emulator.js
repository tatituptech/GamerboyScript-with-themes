/*
  VBA Emscripten wrapper for qb-gameboy NUI.

  Place your compiled VisualBoyAdvance Emscripten build files in the same folder:
    - html/emulator/vba.js
    - html/emulator/vba.wasm

  This wrapper will:
    - load vba.js dynamically
    - detect either a high-level window.VBA API or an Emscripten Module
    - expose window.Emulator with the minimal API expected by the NUI:
        init(canvas), loadROM(arrayBuffer), saveState() -> ArrayBuffer|base64|null,
        loadState(state), stop()

  Notes:
    - Different Emscripten builds expose different symbols. This wrapper tries common patterns
      and logs useful errors. If your build exports different C function names, edit the ccall
      names below or recompile/export the matching symbols.
*/

(function () {
  const BASE = 'emulator/'
  const VBA_JS = BASE + 'vba.js'
  const WAITS = 5000

  function loadScript(src) {
    return new Promise((resolve, reject) => {
      const s = document.createElement('script')
      s.src = src
      s.onload = () => resolve()
      s.onerror = (e) => reject(new Error('Failed to load ' + src))
      document.head.appendChild(s)
    })
  }

  function timeout(ms) { return new Promise((res) => setTimeout(res, ms)) }

  function waitFor(conditionFn, timeoutMs = WAITS) {
    const interval = 50
    return new Promise((resolve, reject) => {
      const start = Date.now()
      (function poll() {
        try {
          if (conditionFn()) return resolve()
        } catch (e) { /* ignore */ }
        if (Date.now() - start > timeoutMs) return reject(new Error('timeout'))
        setTimeout(poll, interval)
      })()
    })
  }

  function isArrayBuffer(obj) {
    return obj && typeof obj.byteLength === 'number'
  }

  async function init() {
    // Try to load the compiled VBA JS. If it doesn't exist, bail out.
    try {
      await loadScript(VBA_JS)
    } catch (e) {
      console.warn('VBA JS not found at', VBA_JS, '- wrapper will not enable an emulator.')
      return // leave window.Emulator undefined -> UI will show warning
    }

    // Wait for either a high-level window.VBA or an Emscripten Module to appear
    try {
      await waitFor(() => (window.VBA && typeof window.VBA.loadROM === 'function') || window.Module, WAITS)
    } catch (e) {
      console.error('VBA runtime did not initialize in time. The compiled build may use a different init pattern.')
      return
    }

    // Provide the simple API
    const API = {
      _canvas: null,
      _module: window.Module || null,
      _vbaHighLevel: (typeof window.VBA !== 'undefined'),
      init(canvas) {
        this._canvas = canvas
        if (this._vbaHighLevel) {
          try {
            // If the build provides an init(canvas) or setCanvas, call it
            if (window.VBA.init) window.VBA.init(canvas)
            else if (window.VBA.setCanvas) window.VBA.setCanvas(canvas)
          } catch (e) {
            console.warn('VBA.init threw:', e)
          }
        } else if (this._module) {
          // Some builds expect a canvas id or Module.canvas. Try to set Module.canvas if available.
          try {
            if (this._module.setCanvas) this._module.setCanvas(canvas)
            // otherwise, Emscripten may attach automatically to the <canvas> element
          } catch (e) {
            console.warn('Module.setCanvas error', e)
          }
        }
      },

      async loadROM(arrayBuffer) {
        if (!isArrayBuffer(arrayBuffer)) {
          throw new Error('loadROM expects an ArrayBuffer')
        }

        // High-level JS bridge provided by the build
        if (this._vbaHighLevel) {
          if (typeof window.VBA.loadROM === 'function') {
            return window.VBA.loadROM(arrayBuffer)
          }
        }

        // Fallback: use Emscripten FS, write file, call ccall to load
        if (this._module && this._module.FS) {
          const filename = '/rom.gb'
          try {
            // remove old file if exists
            try { this._module.FS.unlink(filename) } catch (_) { /* ignore */ }

            this._module.FS_createDataFile('/', 'rom.gb', new Uint8Array(arrayBuffer), true, true)

            // Try several common exported C functions. If your build exports different names,
            // recompile or edit the names below.
            const tryCalls = [
              { name: 'vba_load_file', args: ['string'], vals: ['rom.gb'], returns: 'number' },
              { name: 'vba_load_rom', args: ['string'], vals: ['rom.gb'], returns: 'number' },
              { name: 'load_rom_from_file', args: ['string'], vals: ['rom.gb'], returns: 'number' }
            ]
            const ccall = this._module.ccall ? this._module.ccall.bind(this._module) : null
            let called = false
            if (ccall) {
              for (const t of tryCalls) {
                try {
                  ccall(t.name, t.returns || 'number', t.args || [], t.vals || [])
                  called = true
                  break
                } catch (e) {
                  // try next
                }
              }
            }
            // If no ccall available or calls failed, attempt to call a high-level entrypoint if present
            if (!called) {
              if (this._module._vba_load_file) {
                // if the symbol is present, call it via cwrap
                try {
                  const fn = this._module.cwrap('vba_load_file', 'number', ['string'])
                  fn('rom.gb')
                  called = true
                } catch (e) { /* ignore */ }
              }
            }

            // Start the emulator if there's a start function
            try {
              if (ccall) {
                try { ccall('vba_start', 'void', [], []) } catch (_) {}
                try { ccall('vba_run', 'void', [], []) } catch (_) {}
              } else if (this._module._vba_start && this._module.cwrap) {
                try {
                  const startFn = this._module.cwrap('vba_start', 'void', [])
                  startFn()
                } catch (e) { /* ignore */ }
              }
            } catch (e) { console.warn('start attempt failed', e) }

            if (!called) {
              console.warn('Could not call any expected exported symbol to load ROM. See README to adapt exports.')
            }
            return true
          } catch (e) {
            console.error('Failed to load ROM into Module FS', e)
            throw e
          }
        }

        throw new Error('No compatible VBA runtime found to load ROM.')
      },

      saveState() {
        // Prefer high-level API if present
        if (this._vbaHighLevel) {
          if (typeof window.VBA.saveState === 'function') {
            return window.VBA.saveState()
          }
        }

        // Fallback: attempt to call an exported save function and read state file from FS
        if (this._module && this._module.ccall && this._module.FS) {
          try {
            // common pattern: call vba_save_state -> writes /state.sav
            try {
              this._module.ccall('vba_save_state', 'void', [], [])
            } catch (_) { /* ignore */ }

            // read state file if it exists
            const path = '/state.sav'
            try {
              const data = this._module.FS.readFile(path, { encoding: 'binary' })
              // return as ArrayBuffer
              return data.buffer || new Uint8Array(data).buffer
            } catch (e) {
              console.warn('No /state.sav found in FS after saveState attempt')
            }
          } catch (e) {
            console.warn('saveState fallback failed', e)
            return null
          }
        }

        return null
      },

      loadState(state) {
        if (!state) return
        // High-level
        if (this._vbaHighLevel && typeof window.VBA.loadState === 'function') {
          return window.VBA.loadState(state)
        }

        // Fallback: write state to FS and call ccall to load it
        if (this._module && this._module.FS) {
          try {
            const bytes = (typeof state === 'string') ? (function () {
              // assume base64 -> ArrayBuffer
              const bin = atob(state)
              const len = bin.length
              const arr = new Uint8Array(len)
              for (let i = 0; i < len; i++) arr[i] = bin.charCodeAt(i)
              return arr
            })() : new Uint8Array(state)

            // write to /state.sav
            try { this._module.FS.unlink('/state.sav') } catch (_) {}
            this._module.FS_createDataFile('/', 'state.sav', bytes, true, true)

            // try typical ccall name
            try {
              if (this._module.ccall) this._module.ccall('vba_load_state', 'void', [], [])
            } catch (e) {
              // ignore
            }
            return true
          } catch (e) {
            console.warn('loadState fallback failed', e)
            return false
          }
        }

        return false
      },

      stop() {
        if (this._vbaHighLevel) {
          if (typeof window.VBA.stop === 'function') {
            try { window.VBA.stop() } catch (e) { console.warn(e) }
          }
          return
        }
        if (this._module && this._module.ccall) {
          try {
            this._module.ccall('vba_stop', 'void', [], [])
          } catch (e) { /* ignore */ }
        }
      }
    }

    // Expose to the page
    window.Emulator = API
    console.info('VBA wrapper ready; window.Emulator is available.')
  }

  // run init (don't await)
  init().catch((e) => {
    console.error('VBA wrapper initialization error', e)
  })
})()