```markdown
Skins for qb-gameboy NUI
========================

Where to put skins
- Each skin is a folder under html/skins/<skin-id>/
- Required files per skin:
  - frame.png (the visual frame/background for the device)
  - skin.json (metadata: frame path + screen rectangle coordinates)

Example structure:
html/
  skins/
    skins.json          # index of skins used by the NUI
    classic/
      frame.png
      skin.json
    dark/
      frame.png
      skin.json

Notes about coordinates
- skin.json.screen uses pixels measured against the overlay container design size (640x360).
- left/top/width/height are applied directly to the #screen-area element.
- If you design skins in a different reference size, adjust values accordingly or use percentages in the future.

Creating frame images
- Design your PNG frame at 640x360 or another chosen design size (the CSS expects 640x360 by default).
- The screen cutout should match the coordinates set in skin.json.
- Use transparent interior where the canvas shows through (frame PNG can include art around the screen, but the screen area itself will be covered by the canvas element).

Testing
1. Put frames and skin.json files into html/skins/.
2. Restart the resource.
3. In-game, place the prop and open the Gameboy NUI.
4. Use the skin selector to change skins and confirm the canvas aligns with the frame cutout.

If the NUI doesn't list skins
- Check browser console (F8 -> Inspect -> Console) for errors (fetch of skins/skins.json or skin.json).
- If your server doesn't allow directory listing, ensure skins.json exists and references the skins explicitly (we included an example).

If you want a new skin pack
- Provide PNG frames sized to 640x360 and the desired screen rectangle and I can generate appropriate skin.json entries for you.
```