// Overlay NUI script: skin loading, apply positioning, open/close handling, basic controls.
// Expected assets:
//  - html/skins/skins.json  (list of skins)
//  - html/skins/<id>/skin.json  (frame path + screen area coordinates)
//  - html/skins/<id>/frame.png  (image file used as frame)
// Emulator API: expects window.Emulator with init(canvas), loadROM(arrayBuffer), saveState(), loadState(state), stop()

const app = document.getElementById('app');
const overlay = document.getElementById('overlay-container');
const skinFrame = document.getElementById('skin-frame');
const skinSelect = document.getElementById('skin-select');
const btnClose = document.getElementById('btn-close');
const btnLoadROM = document.getElementById('btn-load-rom');
const btnSaveState = document.getElementById('btn-save-state');
const btnLoadState = document.getElementById('btn-load-state');
const canvas = document.getElementById('gb-screen');
const screenArea = document.getElementById('screen-area');

const SKINS_LIST = 'skins/skins.json';
const SKINS_BASE = 'skins/'; // directory containing each skin folder
const DEFAULT_SKIN = 'classic';

let skins = [];
let currentSkin = localStorage.getItem('qb_skin') || DEFAULT_SKIN;

// Utility: fetch JSON file, return null on failure
async function fetchJson(path) {
  try {
    const res = await fetch(path, { cache: 'no-cache' });
    if (!res.ok) return null;
    return await res.json();
  } catch (e) {
    return null;
  }
}

// Populate skin selector from skins.json
async function loadSkins() {
  const list = await fetchJson(SKINS_LIST);
  if (!list || !Array.isArray(list)) {
    // Fallback: pre-populated small list
    skins = [
      { id: 'classic', label: 'Classic (Default)' },
      { id: 'dark', label: 'Dark' }
    ];
  } else {
    skins = list;
  }

  skinSelect.innerHTML = '';
  skins.forEach(s => {
    const opt = document.createElement('option');
    opt.value = s.id;
    opt.textContent = s.label || s.id;
    skinSelect.appendChild(opt);
  });

  if (!skins.find(s => s.id === currentSkin)) {
    currentSkin = DEFAULT_SKIN;
  }
  skinSelect.value = currentSkin;
  applySkin(currentSkin);
}

// Apply skin by loading its skin.json and setting frame + screen area
async function applySkin(skinId) {
  const meta = await fetchJson(`${SKINS_BASE}${skinId}/skin.json`);
  if (!meta) {
    console.warn('Skin metadata not found for', skinId);
    // fallback: use a simple CSS background if frame exists
    skinFrame.style.backgroundImage = `url("${SKINS_BASE}${skinId}/frame.png")`;
    // keep current screen-area
    localStorage.setItem('qb_skin', skinId);
    currentSkin = skinId;
    return;
  }

  // Set frame image
  const framePath = meta.frame || `skins/${skinId}/frame.png`;
  skinFrame.style.backgroundImage = `url("${framePath}")`;

  // If metadata contains screen coordinates, apply them
  if (meta.screen && typeof meta.screen === 'object') {
    const s = meta.screen;
    // meta values are expected in the skin's design pixels (matching container 640x360).
    // Convert numbers to CSS values (px). You can also support percentages if desired.
    if (typeof s.left === 'number') screenArea.style.left = s.left + 'px';
    if (typeof s.top === 'number') screenArea.style.top = s.top + 'px';
    if (typeof s.width === 'number') screenArea.style.width = s.width + 'px';
    if (typeof s.height === 'number') screenArea.style.height = s.height + 'px';
    if (s.borderRadius) screenArea.style.borderRadius = s.borderRadius;
  }

  // Save selection
  localStorage.setItem('qb_skin', skinId);
  currentSkin = skinId;
}

// NUI messages from client
window.addEventListener('message', (ev) => {
  const d = ev.data;
  if (!d) return;
  if (d.action === 'open') {
    app.classList.remove('hidden');
    app.setAttribute('aria-hidden', 'false');
    // Initialize emulator canvas if available
    try {
      if (window.Emulator && typeof window.Emulator.init === 'function') {
        window.Emulator.init(canvas);
      }
    } catch (e) {
      console.warn('Emulator init failed', e);
    }
  } else if (d.action === 'close') {
    app.classList.add('hidden');
    app.setAttribute('aria-hidden', 'true');
  } else if (d.action === 'setSkin' && d.skin) {
    skinSelect.value = d.skin;
    applySkin(d.skin);
  }
});

// Selector change
skinSelect.addEventListener('change', () => applySkin(skinSelect.value));

// Close button posts to the parent resource to release focus
btnClose.addEventListener('click', () => {
  fetch(`https://${GetParentResourceName()}/close`, { method: 'POST', body: JSON.stringify({}) });
  app.classList.add('hidden');
});

// Load ROM button triggers file picker
btnLoadROM.addEventListener('click', () => {
  const input = document.createElement('input');
  input.type = 'file';
  input.accept = '.gb,.gbc,.gba';
  input.onchange = async (e) => {
    const f = e.target.files[0];
    if (!f) return;
    const ab = await f.arrayBuffer();
    try {
      if (window.Emulator && typeof window.Emulator.loadROM === 'function') {
        await window.Emulator.loadROM(ab);
        console.info('ROM loaded into emulator via window.Emulator.loadROM');
      } else {
        console.warn('No window.Emulator.loadROM available');
      }
    } catch (err) {
      console.error('Failed to load ROM into emulator', err);
    }
  };
  input.click();
});

// Save state and Load state use emulator API and local storage
btnSaveState.addEventListener('click', async () => {
  try {
    if (!window.Emulator || typeof window.Emulator.saveState !== 'function') {
      alert('Emulator does not support saveState in this build.');
      return;
    }
    const state = await window.Emulator.saveState();
    if (!state) { alert('No state produced.'); return; }
    // store as base64 in localStorage for convenience
    const u8 = new Uint8Array(state);
    let binary = '';
    for (let i = 0; i < u8.length; i++) binary += String.fromCharCode(u8[i]);
    const b64 = btoa(binary);
    localStorage.setItem('qb_saved_state', b64);
    alert('State saved locally in NUI storage.');
  } catch (e) {
    console.error(e);
    alert('Save failed: ' + e);
  }
});

btnLoadState.addEventListener('click', async () => {
  try {
    const b64 = localStorage.getItem('qb_saved_state');
    if (!b64) { alert('No saved state found.'); return; }
    // convert base64 back to ArrayBuffer
    const bin = atob(b64);
    const arr = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i);
    const ok = await window.Emulator.loadState(arr.buffer);
    if (ok) alert('State loaded.');
    else alert('Load state attempted; emulator may require a restart to pick it up.');
  } catch (e) {
    console.error(e);
    alert('Load failed: ' + e);
  }
});

// Initialization
(async function () {
  await loadSkins();
})();