╾━╤デ╦︻(˙ ͜ʟ˙ ) TATITUPTECH DID DAT╾━╤デ╦︻(˙ ͜ʟ˙ )

I OWN RITES TO THIS SCRIPT


```markdown
# qb-gameboy (QB-Core) — VisualBoyAdvance integration

This update adds a wrapper so you can use a VisualBoyAdvance Emscripten build (vba.js + vba.wasm) with the existing NUI.

What you need to add
1. Place the compiled VisualBoyAdvance Emscripten files into:
   - html/emulator/vba.js
   - html/emulator/vba.wasm

2. The wrapper (already included) must be present at:
   - html/emulator/emulator.js
   (the wrapper will be loaded by the UI and will attempt to initialize the runtime)

How it works
- The wrapper tries to detect:
  - a high-level JS API exposed as window.VBA with methods like init(canvas), loadROM(arrayBuffer), saveState(), loadState(state), stop()
  - or an Emscripten Module that exposes FS and ccall/cwrap; in that case the wrapper writes ROM bytes to the Module FS and attempts to call common C entrypoints (vba_load_file, vba_start, vba_run, vba_save_state, vba_load_state, vba_stop). If your compiled build uses different function names, update html/emulator/emulator.js to match.

Testing
- Start your server and ensure the resource is started.
- Use the in-game item / place the prop and open the UI.
- Use "Load ROM" to choose a local .gb/.gbc file or use the ROM list (if you host ROM files in html/roms/).
- The wrapper will try to initialize the emulator and run the ROM.

If it doesn't work
- Check the client console (F8 or browser console for the NUI) for messages from the wrapper.
- If the wrapper cannot find exported symbols, you have two options:
  1. Use a prebuilt Emscripten port of VisualBoyAdvance that exposes a high-level window.VBA JS API. The wrapper will use that automatically.
  2. Recompile VisualBoyAdvance with Emscripten and export functions with names the wrapper expects (or adapt the wrapper to the exported names).

If you'd like, I can:
- Provide detailed Emscripten build steps and a small source patch to export the exact C functions the wrapper calls, so you can compile vba.js/vba.wasm that work out-of-the-box.
- Or adapt the wrapper to whatever prebuilt port you find (tell me the port/source and I will adapt the wrapper to its API).

Legal note
- This project does NOT include game ROMs. Only use ROMs you legally own.
```