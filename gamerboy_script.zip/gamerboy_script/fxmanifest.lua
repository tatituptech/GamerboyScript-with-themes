fx_version 'cerulean'
game 'gta5'


╾━╤デ╦︻(˙ ͜ʟ˙ ) TATITUPTECH DID DAT╾━╤デ╦︻(˙ ͜ʟ˙ )
author 'tatituptech'
description 'QB-Core Gameboy prop + ROMs)'
version '1.0.0'

shared_script 'config.lua'
client_script 'client/main.lua'
server_script 'server/main.lua'

ui_page 'html/index.html'

files {
  'html/index.html',
  'html/style.css',
  'html/script.js',
  'html/icons/*',
  -- emulator and rom folders are optional. Put your emulator library (emulator.js) in html/emulator/
  -- and GB ROMs (example.gb) in html/roms/ if you want them served by the NUI.
  'html/emulator/*',
  'html/roms/*'
}