local QBCore = exports['qb-core']:GetCoreObject()

-- Make the item usable. When used, it triggers the client to place a gameboy prop.
QBCore.Functions.CreateUseableItem(Config.UsableItem, function(source, item)
    TriggerClientEvent('qb-gameboy:client:place', source)
end)

-- Optional command to let admins spawn it quickly
QBCore.Commands.Add("gameboy", "Place a Gameboy prop (admin)", {}, false, function(source, args)
    TriggerClientEvent('qb-gameboy:client:place', source)
end, "admin")